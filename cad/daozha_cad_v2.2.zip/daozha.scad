// =====================================================================
//  道闸玩具 v2.2 · 参数化结构件
//  依据: 道闸玩具_电路与结构设计方案_v2.md
//
//  坐标约定 (OpenSCAD Z 朝上):
//    X  = 前后。-X = 长脚侧(按键 / Type-C)，+X = 闸杆伸出侧(道路)
//    Y  = 车辆行驶方向 (对应设计文档里的 Z 轴)
//    Z  = 高度，Z=0 为底座底面
//
//  v2.1 -> v2.2 修复:
//    - 闸体内腔挖穿顶面 -> 补回 2mm 顶盖
//    - 闸体底面被整个切开导致螺柱/托架悬空 -> 补回 2mm 底板 + 走线孔
//    - 微动开关座悬空 -> 改为贴内壁的整体托板
//    - 底座/遥控器内部特征被内腔减掉 -> 移出 difference() 之后再并集
//    - 电机托架 X 未居中、让位孔够不到 -> 重建
//    - 机械止挡筋是空块 -> 补建
//    - 新增 layout 视图, 可看内部元件排布
// =====================================================================

// GUI 里改这个字符串:
part = "assembly";
// assembly | layout | base_tray | base_top | house_l | house_r | hub
// bar_a | bar_b | rc_bottom | rc_top

// 命令行用数字 (避开 shell 传引号的麻烦):
//   openscad -D p=3 -o stl/house_l.stl daozha.scad
p = 0;
PARTS = ["assembly", "layout", "base_tray", "base_top", "house_l",
         "house_r", "hub", "bar_a", "bar_b", "rc_bottom", "rc_top"];
sel = (p == 0) ? part : PARTS[p];

$fn = 48;

/* ============ 通用配合参数 ============ */
WALL       = 2.0;
GAP        = 0.25;
BOSS_OD    = 4.4;
BOSS_PILOT = 1.7;
SCREW_CLR  = 2.4;
HEAD_D     = 4.4;

/* ============ 底座 ============ */
BASE_L = 150;  BASE_W = 55;  BASE_H = 20;
TOP_T  = 3;
TRAY_H = BASE_H - TOP_T;      // 17
BASE_R = 3;

BTN_X = [-50, -30];
BTN_D = 6.5;

USB_W = 10;  USB_H = 5;  USB_Z = 8;
PSW_W = 8;   PSW_H = 4;  PSW_Y = 19;

BAT_L = 50;  BAT_W = 34;  BAT_T = 10;
BAT_CX = -46;

PCB_L = 63;  PCB_W = 25.5;  PCB_CX = 11;  PCB_CY = 10;

// 小模块位置 [中心X, 中心Y, 长, 宽]: TP4056 / 5V升压 / DRV8833
// 三者互不重叠, 且限位柱不得戳穿 x=73 / y=±25.5 内壁
MODULES = [[57, 13, 26, 17], [54, -1, 17, 11], [57, -15, 18, 15]];

/* ============ 闸体 (局部原点 = 闸体底面中心, 绝对 X = +25) ============ */
HS_L = 46;  HS_W = 46;  HS_H = 62;  HS_R = 3;
HS_X_ABS = 25;
PIV_Z = 22;

WIRE_D = 8;
WIRE_P = [0, -16.5];          // 走线孔 (闸体局部 XY), 避开螺柱与电机座

HUB_J_D    = 8;
CAM_BASE_D = 12;
CAM_LOBE_D = 18;
CAM_ARC    = 25;
SW_HOLE_R  = 12.5;            // 微动开关安装孔半径 (需实物微调)
SW_SPACING = 9.5;
MIC_Z      = 38;

MOT_D      = 12.4;
MOT_GB     = 12.6;            // N20 减速箱方形边长(含间隙)
MOT_BOSS_D = 16;
MOT_BOSS_H = 4;

STOP_ANG   = 100;

// 调试开关: 全部默认 true。-D FEAT=false 只出裸壳; F1~F4 可单独关掉排查
FEAT = true;
F1 = true;   // 底部固定螺柱
F2 = true;   // 左右壳对拧螺柱
F3 = true;   // 电机座
F4 = true;   // 微动开关托板

// 闸体底部固定螺柱: 4 角对称, 每半壳各 2 个, 立在底板上
HS_BOSS = [[15, 15], [15, -15], [-15, 15], [-15, -15]];
// 左右壳对拧螺柱: 必须贴到侧壁 + 底板/顶盖, 否则会悬空
// x=±19.2 使 φ4.4 螺柱嵌进 x=±21 内壁
// z 取 3.5 / 58.5 让螺柱真正插进底板和顶盖 —— 不能取"刚好相切"的 4.2 / 57.8,
// 相切接触会产生非流形边 (Simple: no)
HS_JOIN = [[-19.2, 3.5], [19.2, 3.5], [-19.2, 58.5], [19.2, 58.5]];

/* ============ 闸杆 ============ */
BAR_W = 5;  BAR_H = 8;  BAR_WALL = 1.2;
BAR_A_BODY = 150;  BAR_B = 150;  BAR_LAP = 20;  BAR_ROOT = 20;
STRIPE = 37.5;  STRIPE_D = 0.4;

/* ============ 遥控器 ============ */
RC_L = 60;  RC_W = 30;  RC_H = 20;  RC_R = 4;  RC_TOP_T = 3;
RC_BTN_X = [-18, 0, 18];
RC_BTN_D = 6;

/* =====================================================================
   通用模块
   ===================================================================== */
module rbox(l, w, h, r) {
    hull() for (x = [-l/2 + r, l/2 - r], y = [-w/2 + r, w/2 - r])
        translate([x, y, 0]) cylinder(r = r, h = h);
}

// 螺柱: 底孔从本地 z=0 面开口 (螺丝从该面拧入)
module boss_open(h) {
    difference() {
        cylinder(d = BOSS_OD, h = h);
        translate([0, 0, -0.5]) cylinder(d = BOSS_PILOT, h = h);
    }
}

// 螺柱: 底孔从顶面开口
module boss_top(h) {
    difference() {
        cylinder(d = BOSS_OD, h = h);
        translate([0, 0, 0.5]) cylinder(d = BOSS_PILOT, h = h);
    }
}

module csk(h) {
    translate([0, 0, -1]) cylinder(d = SCREW_CLR, h = h + 2);
    translate([0, 0, h - 1.4]) cylinder(d1 = SCREW_CLR, d2 = HEAD_D, h = 1.5);
}

BASE_BOSS = [[-BASE_L/2 + 9,  BASE_W/2 - 9], [-BASE_L/2 + 9, -BASE_W/2 + 9],
             [ BASE_L/2 - 9,  BASE_W/2 - 9], [ BASE_L/2 - 9, -BASE_W/2 + 9]];

/* =====================================================================
   1. 底座下托盘
      注意: 内腔在 difference 里挖，内部特征在 difference 之后加
   ===================================================================== */
module base_tray() {
    // --- 壳体 ---
    difference() {
        rbox(BASE_L, BASE_W, TRAY_H, BASE_R);
        translate([0, 0, WALL])
            rbox(BASE_L - 2*WALL, BASE_W - 2*WALL, TRAY_H, BASE_R - 0.6);
        // Type-C (前端面)
        translate([-BASE_L/2 - 1, -USB_W/2, USB_Z - USB_H/2])
            cube([WALL + 2, USB_W, USB_H]);
        // 总电源开关 (前端面)
        translate([-BASE_L/2 - 1, PSW_Y - PSW_W/2, USB_Z - PSW_H/2])
            cube([WALL + 2, PSW_W, PSW_H]);
    }
    // --- 内部特征: 一律从 z=WALL-1 起长, 往底板里埋 1mm 实体互穿 ---
    Z0 = WALL - 1;
    // 角螺柱
    for (p = BASE_BOSS) translate([p[0], p[1], Z0]) boss_top(TRAY_H - WALL + 1);
    // 电池围挡 (103450 卧放): 4 条挡边
    for (s = [-1, 1]) {
        translate([BAT_CX + s*(BAT_L/2 + 1.5) - 1.5, -(BAT_W + 6)/2, Z0])
            cube([3, BAT_W + 6, BAT_T + 1]);
        translate([BAT_CX - (BAT_L + 6)/2, s*(BAT_W/2 + 1.5) - 1.5, Z0])
            cube([BAT_L + 6, 3, BAT_T + 1]);
    }
    // 主控板支撑柱 (DevKitC-1 平放)
    for (x = [-1, 1], y = [-1, 1])
        translate([PCB_CX + x*(PCB_L/2 - 4), PCB_CY + y*(PCB_W/2 - 3), Z0])
            cylinder(d = 5, h = 3.5);
    // 主控板两端限位挡边
    for (x = [-1, 1])
        translate([PCB_CX + x*(PCB_L/2 + 1.5) - 1.5, PCB_CY - (PCB_W - 6)/2, Z0])
            cube([3, PCB_W - 6, 7]);
    // 小模块限位角柱 (TP4056 / 升压 / DRV8833, 尺寸按实测微调)
    for (m = MODULES)
        for (sx = [-1, 1], sy = [-1, 1])
            translate([m[0] + sx*(m[2]/2 + 1), m[1] + sy*(m[3]/2 + 1), Z0])
                cylinder(d = 2.6, h = 6);
}

/* =====================================================================
   2. 底座上盖板
   ===================================================================== */
module base_top() {
    difference() {
        union() {
            rbox(BASE_L, BASE_W, TOP_T, BASE_R);
            translate([0, 0, -2])
                rbox(BASE_L - 2*WALL - 2*GAP, BASE_W - 2*WALL - 2*GAP, 2.01, BASE_R - 0.6);
        }
        // 按键孔
        for (x = BTN_X) translate([x, 0, -4]) cylinder(d = BTN_D, h = TOP_T + 8);
        // 走线孔 (与闸体底板对齐)
        translate([HS_X_ABS + WIRE_P[0], WIRE_P[1], -4]) cylinder(d = WIRE_D, h = TOP_T + 8);
        // 角螺丝沉头孔
        for (p = BASE_BOSS) translate([p[0], p[1], 0]) csk(TOP_T);
        // 闸体固定孔 (从盖板底面往上拧进闸体螺柱, 闸体外表面无螺丝)
        for (p = HS_BOSS) translate([HS_X_ABS + p[0], p[1], 0]) rotate([180, 0, 0])
            translate([0, 0, -TOP_T]) csk(TOP_T);
    }
}

/* =====================================================================
   3. 闸体
   ===================================================================== */
// 结构顺序很关键:
//   先 (壳体 - 内腔), 再并上实体特征, 最后统一开孔。
//   如果在挖完内腔后才 union 带孔的螺柱, union 会把孔在底板段重新填实,
//   底孔就变成上下封死的盲腔 (CGAL 里表现为多出来的 volume)。
module housing_shell() {
    difference() {
        union() {
            // --- 壳体 ---
            difference() {
                union() {
                    rbox(HS_L, HS_W, HS_H, HS_R);
                    // 电机尾部外凸包 (+Y 面): N20 比内腔长约 2mm, 必须让位
                    translate([0, HS_W/2 - 1, PIV_Z]) rotate([-90, 0, 0])
                        cylinder(d = MOT_BOSS_D, h = MOT_BOSS_H + 1);
                    stop_rib();
                }
                // 内腔: 底板 2mm + 顶盖 2mm 都保留
                translate([0, 0, WALL])
                    rbox(HS_L - 2*WALL, HS_W - 2*WALL, HS_H - 2*WALL, HS_R - 0.6);
                // 走线孔 (穿底板)
                translate([WIRE_P[0], WIRE_P[1], -1]) cylinder(d = WIRE_D, h = WALL + 2);
                // 轴颈孔 (-Y 壁)
                translate([0, -HS_W/2 - 1, PIV_Z]) rotate([-90, 0, 0])
                    cylinder(d = HUB_J_D + 2*GAP, h = WALL + 2);
                // 电机尾部让位腔
                translate([0, HS_W/2 - WALL - 0.01, PIV_Z]) rotate([-90, 0, 0])
                    cylinder(d = MOT_D, h = MOT_BOSS_H + WALL + 1);
                // 麦克风格栅 (-X 面, 朝使用者, 全部落在 -Y 半壳)
                for (i = [0 : 3])
                    translate([-HS_L/2 - 1, -13 + i*3.5, MIC_Z]) rotate([0, 90, 0])
                        cylinder(d = 1.8, h = WALL + 2);
            }
            // --- 实体特征 (不带孔) ---
            if (FEAT) {
                if (F1) for (p = HS_BOSS)
                    translate([p[0], p[1], 0]) cylinder(d = BOSS_OD, h = 12);
                if (F2) for (p = HS_JOIN)
                    translate([p[0], 0, p[1]]) rotate([90, 0, 0]) cylinder(d = BOSS_OD, h = 9);
                if (F3) motor_seat();
                if (F4) switch_plate();
            }
        }
        // --- 最后统一开孔, 保证贯穿所有材料 ---
        if (FEAT) {
            if (F1) for (p = HS_BOSS)
                translate([p[0], p[1], -1]) cylinder(d = BOSS_PILOT, h = 12);
            if (F2) for (p = HS_JOIN)
                translate([p[0], 1, p[1]]) rotate([90, 0, 0])
                    cylinder(d = BOSS_PILOT, h = 9.5);
            if (F4) switch_holes();
        }
    }
}

// 机械止挡筋: 100° 软后挡, 正常不接触, 限位失效时兜底
module stop_rib() {
    // 深度取 11 (y=-30..-19), 让筋伸进内腔 2mm, 由内腔切削干净地切平在 y=-21;
    // 若刚好停在 -21 会与内腔面重合, 同样产生非流形
    translate([0, 0, PIV_Z]) rotate([0, -STOP_ANG, 0])
        translate([9, -HS_W/2 - 7, -3.5]) cube([6, 11, 7]);
}

// 电机座: -Y 半是减速箱方座, +Y 半是机身圆弧托
module motor_seat() {
    difference() {
        union() {
            // 往底板里埋 1.5mm
            translate([-9.5, -11, WALL - 1.5]) cube([19, 8, PIV_Z + 1.5]);
            for (yy = [3, 15]) translate([-9.5, yy, WALL - 1.5]) cube([19, 3, PIV_Z + 1.5]);
        }
        // 减速箱方形让位
        translate([-MOT_GB/2, -13, PIV_Z - MOT_GB/2]) cube([MOT_GB, 12, 20]);
        // 机身圆形让位
        translate([0, -30, PIV_Z]) rotate([-90, 0, 0]) cylinder(d = MOT_D, h = 60);
    }
}

SW_HOLES = [[ SW_HOLE_R, -SW_SPACING/2], [ SW_HOLE_R,  SW_SPACING/2],
            [-SW_SPACING/2, SW_HOLE_R],  [ SW_SPACING/2, SW_HOLE_R]];

// 微动开关托板: 3.5mm 实心板整块贴 -Y 内壁, 开关直接拧在板上。
// 不用凸起螺柱 —— 凸柱会把开关顶出凸轮的 Y 覆盖范围(凸轮只有 y=-19..-13 这 6mm)。
YIN = -HS_W/2 + WALL;

module switch_plate() {
    // 往壁里埋 1.2mm, 实体互穿而不是贴面
    translate([-SW_HOLE_R - 5, YIN - 1.2, PIV_Z - SW_HOLE_R - 5])
        cube([2*SW_HOLE_R + 10, 4.7, 2*SW_HOLE_R + 10]);
}

module switch_holes() {
    // 让开凸轮和轴颈
    translate([0, YIN - 2, PIV_Z]) rotate([-90, 0, 0])
        cylinder(d = CAM_LOBE_D + 2, h = 14);
    // 4 个 M2 自攻底孔 (贯穿托板)
    for (q = SW_HOLES)
        translate([q[0], YIN + 4, PIV_Z + q[1]]) rotate([90, 0, 0])
            cylinder(d = BOSS_PILOT, h = 6);
}

module house_l() {
    difference() {
        housing_shell();
        translate([-60, 0, -2]) cube([120, 70, HS_H + 8]);
    }
}

module house_r() {
    difference() {
        housing_shell();
        translate([-60, -70, -2]) cube([120, 70, HS_H + 8]);
        // 对拧过孔: 必须从外表面一路打穿内壁 (原来只在壁上凹了 1mm, 螺丝过不去)
        for (p = HS_JOIN) translate([p[0], HS_W/2, p[1]]) rotate([90, 0, 0]) {
            translate([0, 0, -1]) cylinder(d = SCREW_CLR, h = WALL + 3);
            cylinder(d1 = HEAD_D, d2 = SCREW_CLR, h = 1.6);
        }
    }
}

/* =====================================================================
   4. 转毂 (轴套 + 凸轮 + 闸杆夹, 一件三用)
      本地 Z 轴 = 装配后的 Y 轴
      0..12 夹块 | 12..16 轴颈 | 16..22 凸轮
   ===================================================================== */
module hub() {
    difference() {
        union() {
            cylinder(d = 16, h = 12);
            translate([-8, -7, 0]) cube([16, 14, 12]);
            translate([0, 0, 12]) cylinder(d = HUB_J_D - 2*GAP, h = 4);
            translate([0, 0, 16]) cylinder(d = CAM_BASE_D, h = 6);
            translate([0, 0, 16]) rotate([0, 0, -CAM_ARC/2])
                rotate_extrude(angle = CAM_ARC)
                    translate([CAM_BASE_D/2 - 0.01, 0])
                        square([(CAM_LOBE_D - CAM_BASE_D)/2 + 0.01, 6]);
        }
        // 闸杆插槽 (5x8), 从外端进 14mm
        translate([-1, -(BAR_W + 2*GAP)/2, 2])
            cube([15, BAR_W + 2*GAP, BAR_H + 2*GAP]);
        // 闸杆横穿螺丝
        translate([6, 0, 2 + BAR_H/2]) rotate([90, 0, 0])
            cylinder(d = SCREW_CLR, h = 30, center = true);
        // 电机 D 形轴孔 (φ3, 深 9)
        translate([0, 0, 13]) {
            cylinder(d = 3 + GAP, h = 10);
            translate([-2.5, 0.95, 0]) cube([5, 2, 10]);
        }
        // 顶丝
        translate([0, 0, 18]) rotate([90, 0, 0]) cylinder(d = 1.7, h = 20, center = true);
        // 配重仓 (M5 钢螺母)
        translate([-13.5, -5, 1.5]) cube([6, 10, 9]);
    }
}

/* =====================================================================
   5. 闸杆
   ===================================================================== */
module bar_profile(len) {
    difference() {
        translate([0, -BAR_W/2, 0]) cube([len, BAR_W, BAR_H]);
        translate([-1, -(BAR_W - 2*BAR_WALL)/2, BAR_WALL])
            cube([len + 2, BAR_W - 2*BAR_WALL, BAR_H - 2*BAR_WALL]);
    }
}

// 分色凹槽 (交替 37.5mm), 用于贴反光纸或喷涂遮蔽
module stripes(x0, len) {
    n = floor(len / STRIPE) + 1;
    for (i = [0 : n])
        if (floor((x0 + i*STRIPE + 0.1) / STRIPE) % 2 == 1)
            for (s = [-1, 1])
                translate([x0 + i*STRIPE, s*(BAR_W/2 - STRIPE_D/2), BAR_H/2])
                    cube([STRIPE, STRIPE_D, BAR_H + 2], center = true);
}

module bar_a() {
    difference() {
        union() {
            // 外形实心, 中空另挖; 末端留 12mm 实心堵头, 插榫才有地方生根
            translate([0, -BAR_W/2, 0]) cube([BAR_A_BODY, BAR_W, BAR_H]);
            translate([BAR_A_BODY, -(BAR_W - 2*BAR_WALL - 2*GAP)/2, BAR_WALL + GAP])
                cube([BAR_LAP, BAR_W - 2*BAR_WALL - 2*GAP, BAR_H - 2*BAR_WALL - 2*GAP]);
        }
        // 中空段: 根部实心 20mm 之后开始, 末端实心 12mm 之前结束
        translate([BAR_ROOT, -(BAR_W - 2*BAR_WALL)/2, BAR_WALL])
            cube([BAR_A_BODY - BAR_ROOT - 12, BAR_W - 2*BAR_WALL, BAR_H - 2*BAR_WALL]);
        translate([6, 0, BAR_H/2]) rotate([90, 0, 0]) cylinder(d = 1.9, h = 20, center = true);
        translate([BAR_A_BODY + 10, 0, BAR_H/2]) rotate([90, 0, 0])
            cylinder(d = 1.9, h = 20, center = true);
        // 排气/排料孔: 中空腔两端各一个, 否则是完全密闭腔(树脂打印会存料)
        for (xx = [BAR_ROOT + 6, BAR_A_BODY - 18])
            translate([xx, 0, -1]) cylinder(d = 2, h = BAR_WALL + 2);
        stripes(0, BAR_A_BODY);
    }
}

module bar_b() {
    difference() {
        union() {
            bar_profile(BAR_B - 4);
            translate([BAR_B - 4, -BAR_W/2, 0]) cube([4, BAR_W, BAR_H]);
        }
        translate([10, 0, BAR_H/2]) rotate([90, 0, 0])
            cylinder(d = SCREW_CLR, h = 20, center = true);
        stripes(0, BAR_B);
    }
}

/* =====================================================================
   6. 遥控器
   ===================================================================== */
RC_BOSS = [[-RC_L/2 + 7,  RC_W/2 - 6], [-RC_L/2 + 7, -RC_W/2 + 6],
           [ RC_L/2 - 7,  RC_W/2 - 6], [ RC_L/2 - 7, -RC_W/2 + 6]];

module rc_bottom() {
    difference() {
        rbox(RC_L, RC_W, RC_H - RC_TOP_T, RC_R);
        translate([0, 0, WALL])
            rbox(RC_L - 2*WALL, RC_W - 2*WALL, RC_H, RC_R - 0.6);
        translate([RC_L/2 - WALL - 1, -USB_W/2, 5]) cube([WALL + 2, USB_W, USB_H]);
    }
    // 内部特征 (在 difference 之外, 往底板埋 1mm)
    for (p = RC_BOSS) translate([p[0], p[1], WALL - 1]) boss_top(RC_H - RC_TOP_T - WALL + 1);
    // C3 SuperMini 与 TP4056 之间的隔筋
    translate([-1.5, -RC_W/2 + WALL, WALL - 1]) cube([3, RC_W - 2*WALL, 7]);
    // 电池仓围挡 (502030 立放在一端)
    translate([-RC_L/2 + WALL + 20, -RC_W/2 + WALL, WALL - 1]) cube([2.5, 10, 9]);
}

module rc_top() {
    difference() {
        union() {
            rbox(RC_L, RC_W, RC_TOP_T, RC_R);
            translate([0, 0, -2])
                rbox(RC_L - 2*WALL - 2*GAP, RC_W - 2*WALL - 2*GAP, 2.01, RC_R - 0.6);
        }
        for (x = RC_BTN_X) translate([x, 0, -4]) cylinder(d = RC_BTN_D, h = RC_TOP_T + 8);
        for (p = RC_BOSS) translate([p[0], p[1], 0]) csk(RC_TOP_T);
    }
}

/* =====================================================================
   7. 内部元件排布预览 (仅示意, 不导出)
   ===================================================================== */
module part_block(sz, pos, col) {
    color(col, 0.85) translate([pos[0] - sz[0]/2, pos[1] - sz[1]/2, pos[2]])
        cube(sz);
}

module layout() {
    color("DimGray", 0.35) base_tray();
    part_block([BAT_L, BAT_W, BAT_T],  [BAT_CX, 0, WALL],        "ForestGreen");   // 103450 锂电
    part_block([PCB_L, PCB_W, 13],     [PCB_CX, PCB_CY, WALL+2.5],"SteelBlue");    // ESP32-S3 DevKitC-1
    part_block([MODULES[0][2], MODULES[0][3], 4], [MODULES[0][0], MODULES[0][1], WALL], "Goldenrod");    // TP4056
    part_block([MODULES[1][2], MODULES[1][3], 6], [MODULES[1][0], MODULES[1][1], WALL], "MediumPurple"); // 5V 升压
    part_block([MODULES[2][2], MODULES[2][3], 6], [MODULES[2][0], MODULES[2][1], WALL], "IndianRed");    // DRV8833
    color("DarkOrange", 0.85) translate([-16, -20, WALL]) cylinder(d = 9, h = 5);  // 蜂鸣器
    // 走线孔位置提示
    color("Black", 0.5)
        translate([HS_X_ABS + WIRE_P[0], WIRE_P[1], WALL]) cylinder(d = WIRE_D, h = 15);
}

/* =====================================================================
   8. 装配预览
   ===================================================================== */
module assembly() {
    color("DimGray")   base_tray();
    color("Silver")    translate([0, 0, TRAY_H]) base_top();
    color("Goldenrod") translate([HS_X_ABS, 0, BASE_H]) { house_l(); house_r(); }
    color("SlateGray") translate([HS_X_ABS, -35, BASE_H + PIV_Z]) rotate([-90, 0, 0]) hub();
    color("Crimson")   translate([HS_X_ABS + 6, -30, BASE_H + PIV_Z - BAR_H/2 - 2]) {
                           bar_a();
                           translate([BAR_A_BODY, 0, 0]) bar_b();
                       }
    color("DimGray")   translate([-150, 75, 0]) {
                           rc_bottom();
                           translate([0, 0, RC_H - RC_TOP_T]) rc_top();
                       }
}

/* =====================================================================
   导出分发
   ===================================================================== */
if      (sel == "assembly")   assembly();
else if (sel == "layout")     layout();
else if (sel == "base_tray")  base_tray();
else if (sel == "base_top")   base_top();
else if (sel == "house_l")    house_l();
else if (sel == "house_r")    house_r();
else if (sel == "hub")        hub();
else if (sel == "bar_a")      bar_a();
else if (sel == "bar_b")      bar_b();
else if (sel == "rc_bottom")  rc_bottom();
else if (sel == "rc_top")     rc_top();
